package scripts;

import generic_Lib.BaseClass;

import java.io.File;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Test_1 extends BaseClass {

	public ExtentReports reports;
	public ExtentTest logger;


	//	htmlpage  -- 1
	//	starttest -- 2 
	//	loger  -- 3  
	//	endtest --4 
	//	flush
	//	true -- replace
	//	false -- append

//	1. before test creation 
//	2. After test 
	
	@Test
	public void f() {

		ExtentReports reports = new ExtentReports("ExtentReports//"+getClass().getSimpleName()+".html", true);
		reports.loadConfig(new File(".\\Framework_Maven\\Extent_config.xml"));

		ExtentTest logger = reports.startTest("passTest");
		
		logger.log(LogStatus.PASS, "login succesfully");
		logger.log(LogStatus.INFO, "Test Case Passed is passTest"); 
		logger.log(LogStatus.SKIP, "Test Case Passed is passTest");
		logger.log(LogStatus.FATAL, "Test Case Passed is passTest");
		logger.log(LogStatus.ERROR, "Test Case Passed is passTest");
		logger.log(LogStatus.FAIL, "login failed");

		//After Test
		reports.endTest(logger);
		reports.flush();
		//	  System.out.println("mssages "+Messages.getString("Name")); //$NON-NLS-1$
	}

	@BeforeTest
	public void beforeTest() {
	}

	@AfterTest
	public void afterTest() {
	}

}
