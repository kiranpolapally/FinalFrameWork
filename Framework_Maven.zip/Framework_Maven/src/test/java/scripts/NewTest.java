package scripts;

import generic_Lib.Common_Lib;
import generic_Lib.Driverclass;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest {

	
	
	@BeforeTest
	public void beforetest() {
		System.out.println("Before Test");
		
//		Driverclass.driver    //classname.methodname
		
		Common_Lib.close();
		
		
	}

	@BeforeMethod
	public void BeforeMethod() {
		System.out.println("Before Method");
	}

	@BeforeSuite
	public void BeforeSuite() {
		System.out.println(" Before Suite");
	}

	@AfterSuite
	public void AfterSuite() {
		System.out.println("After Suite");
	}

	@AfterMethod
	public void AfterMethod() {
		System.out.println("After Method");
	}

	@AfterTest
	public void Aftertest() {
		System.out.println("After Test");
	}

	@Test(priority=0)
	public void f() {
		System.out.println("Test");
		
		
		
	}

	@Test(priority=1)
	public void f1() {
		System.out.println("Test 1");
	}

}
