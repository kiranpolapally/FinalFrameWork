package generic_Lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class DBConnections {

	Statement stmt;
	ResultSet rs;
	Connection con;

	public void DBconnect() throws ClassNotFoundException, SQLException{

		//Connection URL Syntax: "jdbc:mysql://ipaddress:portnumber/db_name"		

		String URL = "jdbc:mysql://http://sbs:3036/Automation";
		Class.forName("com.mysql.jdbc.Driver");			
		con = DriverManager.getConnection(URL,"username","password");
		stmt = con.createStatement();					

	}

	public void Statement(String query) throws ClassNotFoundException, SQLException{

		rs= stmt.executeQuery(query);							

		while (rs.next()){
			String Column1 = rs.getString(1);								        
			String Column2 = rs.getString(2);	
			System. out.println(Column1+"  "+Column2);		
			con.close();			

		}
	}
}
