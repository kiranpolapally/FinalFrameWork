package generic_Lib;

import org.openqa.selenium.WebDriver;

 public class Driverclass {
	
	public static WebDriver driver;

}
 
 

 
 